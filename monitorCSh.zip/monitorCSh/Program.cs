﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Collections.Generic;
using System.Threading;

class PCMonitor
{
    static bool loggingEnabled = false;
    static PerformanceCounter cpuCounter;
    static class Colors
    {
        public const string Reset = "\x1b[0m";
        public const string Red = "\x1b[31m";
        public const string Green = "\x1b[32m";
        public const string Yellow = "\x1b[33m";
        public const string Blue = "\x1b[34m";
        public const string Magenta = "\x1b[35m";
        public const string Cyan = "\x1b[36m";
        public const string White = "\x1b[37m";
    }

    static PCMonitor()
    {
        cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
        cpuCounter.NextValue();
    }

    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.Clear();

        while (true)
        {
            PrintMenu();
            string choice = Console.ReadLine();
            Console.WriteLine(new string('-', 40));
            Log($"Выбрана команда: {choice}");

            switch (choice)
            {
                case "1": GetCPUInfo(); break;
                case "2": GetRAMInfo(); break;
                case "3": GetDiskInfo(); break;
                case "4": GetGPUInfo(); break;
                case "5": GetProcessesInfo(); break;
                case "6":
                    loggingEnabled = !loggingEnabled;
                    Console.WriteLine(Colors.Yellow + "Логирование: " + (loggingEnabled ? "Включено" : "Выключено") + Colors.Reset);
                    Log("Логирование: " + (loggingEnabled ? "Включено" : "Выключено"));
                    break;
                case "0": return;
                default:
                    Console.WriteLine(Colors.Red + "Неверный ввод. Попробуйте снова." + Colors.Reset);
                    Log("Неверный ввод");
                    break;
            }
        }
    }

    static void GetCPUInfo()
    {
        var searcher = new ManagementObjectSearcher("select * from Win32_Processor");
        foreach (var item in searcher.Get())
        {
            string info = $"{Colors.Yellow}CPU:{Colors.Reset} {item["Name"]}, {Colors.Cyan}Ядер:{Colors.Reset} {item["NumberOfCores"]}, {Colors.Cyan}Потоков:{Colors.Reset} {item["NumberOfLogicalProcessors"]}, {Colors.Cyan}Частота:{Colors.Reset} {item["MaxClockSpeed"]} МГц";
            Console.WriteLine(info);
            Log(info);
        }

        float cpuLoad = GetCurrentCpuUsage();

        string loadColor = cpuLoad > 80 ? Colors.Red : cpuLoad > 60 ? Colors.Yellow : Colors.Green;
        string loadInfo = $"{Colors.Yellow}Загрузка CPU:{Colors.Reset} {loadColor}{cpuLoad:0.00}%{Colors.Reset}";
        Console.WriteLine(loadInfo);
        Log($"Загрузка CPU: {cpuLoad:0.00}%");
        Console.WriteLine(new string('-', 40));
    }

    static float GetCurrentCpuUsage()
    {
        cpuCounter.NextValue();
        Thread.Sleep(500);
        return cpuCounter.NextValue();
    }

    static void PrintMenu()
    {
        Console.WriteLine(Colors.Cyan + "Выберите действие:" + Colors.Reset);
        Console.WriteLine(Colors.Green + "1" + Colors.Reset + " - Информация о процессоре");
        Console.WriteLine(Colors.Green + "2" + Colors.Reset + " - Информация о памяти");
        Console.WriteLine(Colors.Green + "3" + Colors.Reset + " - Информация о дисках");
        Console.WriteLine(Colors.Green + "4" + Colors.Reset + " - Информация о GPU");
        Console.WriteLine(Colors.Green + "5" + Colors.Reset + " - Список процессов");
        Console.WriteLine(Colors.Green + "6" + Colors.Reset + " - Включить/выключить логирование");
        Console.WriteLine(Colors.Green + "0" + Colors.Reset + " - Выход");
        Console.Write(Colors.Blue + "Введите номер: " + Colors.Reset);
    }

    static void GetRAMInfo()
    {
        var searcher = new ManagementObjectSearcher("select * from Win32_OperatingSystem");
        foreach (var item in searcher.Get())
        {
            ulong total = Convert.ToUInt64(item["TotalVisibleMemorySize"]) / 1024;
            ulong free = Convert.ToUInt64(item["FreePhysicalMemory"]) / 1024;
            ulong used = total - free;
            double usedPercent = (double)used / total * 100;

            string color = usedPercent > 80 ? Colors.Red : usedPercent > 60 ? Colors.Yellow : Colors.Green;
            string info = $"{Colors.Yellow}ОЗУ:{Colors.Reset} {total} MB ({color}Используется: {used} MB ({usedPercent:0.00}%){Colors.Reset}, {Colors.Cyan}Свободно:{Colors.Reset} {free} MB)";
            Console.WriteLine(info);
            Log(info);
        }
        Console.WriteLine(new string('-', 40));
    }

    static void GetDiskInfo()
    {
        foreach (DriveInfo drive in DriveInfo.GetDrives())
        {
            if (drive.IsReady)
            {
                double freePercent = (double)drive.TotalFreeSpace / drive.TotalSize * 100;
                string color = freePercent < 20 ? Colors.Red : freePercent < 30 ? Colors.Yellow : Colors.Green;

                string info = $"{Colors.Yellow}Диск {drive.Name}{Colors.Reset} - {drive.DriveType}, " +
                             $"{Colors.Cyan}Общий объём:{Colors.Reset} {drive.TotalSize / 1024 / 1024 / 1024} GB, " +
                             $"{color}Свободно:{Colors.Reset} {drive.TotalFreeSpace / 1024 / 1024 / 1024} GB ({freePercent:0.00}%)";
                Console.WriteLine(info);
                Log(info);
            }
        }
        Console.WriteLine(new string('-', 40));
    }

    static void GetGPUInfo()
    {
        var searcher = new ManagementObjectSearcher("select * from Win32_VideoController");
        foreach (var item in searcher.Get())
        {
            string info = $"{Colors.Yellow}GPU:{Colors.Reset} {item["Name"]}, {Colors.Cyan}Память:{Colors.Reset} {Convert.ToDouble(item["AdapterRAM"]) / 1024 / 1024 / 1024:0.00} GB";
            Console.WriteLine(info);
            Log(info);
        }
        Console.WriteLine(new string('-', 40));
    }

    static void GetProcessesInfo()
    {
        Console.WriteLine(Colors.Cyan + "Сортировать процессы по:" + Colors.Reset);
        Console.WriteLine(Colors.Green + "1" + Colors.Reset + " - Используемой памяти");
        Console.WriteLine(Colors.Green + "2" + Colors.Reset + " - Загрузке процессора");
        Console.Write(Colors.Blue + "Выберите номер: " + Colors.Reset);
        string choice = Console.ReadLine();
        Log($"Выбрана сортировка процессов по: {(choice == "1" ? "памяти" : "процессору")}");

        List<Process> processes = Process.GetProcesses().ToList();
        var processStats = new List<(Process proc, float cpuUsage, long memory)>();

        foreach (var proc in processes)
        {
            try
            {
                float cpu = 0;
                if (choice == "2")
                {
                    using (var pc = new PerformanceCounter("Process", "% Processor Time", proc.ProcessName, true))
                    {
                        pc.NextValue();
                        Thread.Sleep(50);
                        cpu = pc.NextValue() / Environment.ProcessorCount;
                    }
                }

                processStats.Add((proc, cpu, proc.WorkingSet64));
            }
            catch { }
        }

        var sorted = choice == "1"
            ? processStats.OrderByDescending(x => x.memory)
            : processStats.OrderByDescending(x => x.cpuUsage);

        Console.WriteLine(Colors.Yellow + "Топ-10 процессов:" + Colors.Reset);
        foreach (var (proc, cpu, memory) in sorted.Take(10))
        {
            string cpuColor = cpu > 20 ? Colors.Red : cpu > 10 ? Colors.Yellow : Colors.Green;
            string info = $"{Colors.Magenta}{proc.ProcessName,-30}{Colors.Reset} | " +
                         $"{Colors.Cyan}RAM:{Colors.Reset} {memory / 1024 / 1024,6} MB | " +
                         $"{Colors.Cyan}CPU:{Colors.Reset} {cpuColor}{cpu,6:0.00}%{Colors.Reset} | " +
                         $"{Colors.Cyan}ID:{Colors.Reset} {proc.Id}";
            Console.WriteLine(info);
            Log($"{proc.ProcessName} - RAM: {memory / 1024 / 1024} MB, CPU: {cpu:0.00}%");
        }
        Console.WriteLine(new string('-', 40));
    }

    static void Log(string message)
    {
        if (loggingEnabled)
        {
            string logMessage = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}";
            File.AppendAllText("log.txt", logMessage + "\n");
        }
    }
}
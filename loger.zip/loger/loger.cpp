﻿#include <iostream>  
#include <fstream>  
#include <sstream>  
#include <mutex>  
#include <memory>  
#include <ctime>  
#include <iomanip>  
#include <filesystem>  
#include <map>  

// Кроссплатформенная безопасная обработка времени  
class SafeTime {
public:
    static std::tm getSafeTm(std::time_t time) {
        std::tm result;
#ifdef _WIN32  
        localtime_s(&result, &time);
#else  
        result = *std::localtime(&time);
#endif  
        return result;
    }
};

class Logger {
public:
    enum class Severity { TRACE, DEBUG, INFO, WARNING, ERROR };

    static Logger& getInstance() {
        static Logger instance;
        return instance;
    }

    void setLogLevel(Severity level) {
        logLevel = level;
    }

    void setOutput(bool toConsole, bool toFile, const std::string& filename = "log") {
        logToConsole = toConsole;
        logToFile = toFile;
        if (toFile) {
            std::string uniqueFilename = generateUniqueFilename(filename);
            logFile.open(uniqueFilename, std::ios::out | std::ios::app);
        }
    }

    void log(Severity severity, const std::string& message, const char* file, int line) {
        if (severity < logLevel) return;

        std::ostringstream logEntry;
        logEntry << getCurrentTime() << " | " << severityToString(severity)
            << " | " << file << ":" << line << " -> " << message;

        std::lock_guard<std::mutex> lock(logMutex);
        if (logToConsole) {
            std::cout << logEntry.str() << std::endl;
        }
        if (logToFile && logFile.is_open()) {
            logFile << logEntry.str() << std::endl;
        }
    }

private:
    Severity logLevel = Severity::INFO;
    bool logToConsole = true;
    bool logToFile = false;
    std::ofstream logFile;
    std::mutex logMutex;

    Logger() {}
    ~Logger() {
        if (logFile.is_open()) logFile.close();
    }

    std::string getCurrentTime() {
        auto t = std::time(nullptr);
        std::tm tm = SafeTime::getSafeTm(t);
        std::ostringstream oss;
        oss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
        return oss.str();
    }

    std::string severityToString(Severity severity) {
        static std::map<Severity, std::string> severityMap = {
            {Severity::TRACE, "TRACE"}, {Severity::DEBUG, "DEBUG"},
            {Severity::INFO, "INFO"}, {Severity::WARNING, "WARNING"},
            {Severity::ERROR, "ERROR"}
        };
        return severityMap[severity];
    }

    std::string generateUniqueFilename(const std::string& baseName) {
        auto t = std::time(nullptr);
        std::tm tm = SafeTime::getSafeTm(t);
        std::ostringstream oss;
        oss << baseName << "_" << std::put_time(&tm, "%Y-%m-%d_%H-%M-%S") << ".log";
        return oss.str();
    }
};

// Макросы остаются без изменений  
#define LOG(severity, message) Logger::getInstance().log(Logger::Severity::severity, message, __FILE__, __LINE__)  
#define LOGT(message) LOG(TRACE, message)  
#define LOGD(message) LOG(DEBUG, message)  
#define LOGI(message) LOG(INFO, message)  
#define LOGW(message) LOG(WARNING, message)  
#define LOGE(message) LOG(ERROR, message)  

int main() {
    Logger& logger = Logger::getInstance();
    logger.setLogLevel(Logger::Severity::DEBUG);
    logger.setOutput(true, true, "app_log");

    LOGI("Application started");
    LOGW("This is a warning message");
    LOGE("An error occurred");

    return 0;
}